package com.example.TopExamSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TopExamSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
