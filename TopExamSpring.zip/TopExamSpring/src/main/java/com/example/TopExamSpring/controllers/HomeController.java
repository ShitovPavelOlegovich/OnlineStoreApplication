package com.example.TopExamSpring.controllers;

import com.example.TopExamSpring.model.Person;
import com.example.TopExamSpring.model.Product;
import com.example.TopExamSpring.service.PersonService;
import com.example.TopExamSpring.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.security.Principal;

@Controller
@RequestMapping("/home")
public class HomeController {

    private final ProductService productService;
    private final PersonService personService;


    @Autowired
    public HomeController(ProductService productService, PersonService personService) {
        this.productService = productService;
        this.personService = personService;
    }

//    @GetMapping("/admin")
//    public String adminPage() {
//        return "admin";
//    }

    @GetMapping()
    public String sayHello(Model model) {
        model.addAttribute("products", productService.getAllProducts());
        return "home_page/home";
    }

    @GetMapping("/{id}")
    private String getInfoProduct(Model model, @PathVariable("id") int id) {
        model.addAttribute("product", productService.getOneProduct(id));
        return "product/show";
    }

    @GetMapping("/people")
    public String getAllPerson(Model model, Principal principal ) {
        model.addAttribute("people", productService.getUserByPrincipal(principal));
        return "home_page/home";
    }


    @GetMapping("/person/{id}")
    public String personPage(Model model, @PathVariable("id") int id) {
        Person person = personService.getPersonId(id);
        model.addAttribute("person", person);
        model.addAttribute("people", personService.getAllPerson());
        model.addAttribute("products", person.getProducts());
        return "person/person_page";
    }

//    @GetMapping("/person/{id}")
//    public String person(Model model, @PathVariable("id") int id, Principal principal) {
//        int idPerson = productService.getUserByPrincipal(principal).getId();
//        model.addAttribute("person", idPerson);
//        return "home_page/home";
//    }


//    @GetMapping("/new")
//    public String newProduct(@ModelAttribute("product") Product product) {
//        return "home_page/new";
//    }
//
//    @PostMapping()
//    public String createProduct(@ModelAttribute("product") @Valid Product product, BindingResult bindingResult,
//                                Principal principal) {
//        if(bindingResult.hasErrors()) {
//            return "home_page/new";
//        }
//        productService.createProduct(product,principal);
//        return "redirect:/home";
//    }
//
//    @GetMapping("/{id}/edit")
//    public String editProduct(@ModelAttribute("product") Product product, @PathVariable("id") int id) {
//        productService.getOneProduct(id);
//        return "home_page/edit";
//    }
//
//    @PatchMapping("/{id}")
//    public String updateProduct(@ModelAttribute("product") @Valid Product product, BindingResult bindingResult,
//                                @PathVariable("id") int id, Principal principal) {
//        if (bindingResult.hasErrors()) {
//            return "home_page/edit";
//        }
//        productService.updateProduct(id, product, principal);
//        return "redirect:/home";
//    }
//
//    @DeleteMapping("/{id}")
//    public String deleteProduct(@PathVariable("id") int id) {
//        productService.deleteProduct(id);
//        return "redirect:/home";
//    }


}
