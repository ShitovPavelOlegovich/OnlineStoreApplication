package com.example.TopExamSpring.service;

import com.example.TopExamSpring.model.Person;
import com.example.TopExamSpring.model.Product;
import com.example.TopExamSpring.repositories.PeopleRepository;
import com.example.TopExamSpring.repositories.ProductsRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional(readOnly = true)
public class ProductService {

    private final ProductsRepository productsRepository;
    private final PeopleRepository peopleRepository;

    public List<Product> getAllProducts() {
        log.info("Вывод всех продуктов: ");
        return productsRepository.findAll();
    }

    public List<Product> searchTitle(String title) {
        log.info("Поиск продукта по названию: ");
        return productsRepository.findByTitleStartingWith(title);
    }

    public Product getOneProduct(int id) {
        log.info("Поиск продуктов по id:");
        Optional<Product> book = productsRepository.findById(id);
        return book.orElse(null);
    }

    @Transactional
    public void createProduct(Product product, Principal principal) {
        log.info("Создание продукта: " + product);
        product.setOwnerPerson(getUserByPrincipal(principal));
        productsRepository.save(product);
    }

    @Transactional
    public void updateProduct(int id, Product product, Principal principal) {
        log.info("Редактирование продукта под id: " + id);
        product.setId(id);
        product.setOwnerPerson(getUserByPrincipal(principal));
        product.setDateOfCreated(LocalDateTime.now());
        productsRepository.save(product);
    }

    @Transactional
    public void deleteProduct(int id) {
        log.info("Удаление продукта под id: " + id);
        productsRepository.deleteById(id);
    }

    public Person getUserByPrincipal(Principal principal) {
        return peopleRepository.findByUsername(principal.getName()).orElse(null);
    }



}
