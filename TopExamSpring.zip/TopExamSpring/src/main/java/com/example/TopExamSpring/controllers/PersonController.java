package com.example.TopExamSpring.controllers;

import com.example.TopExamSpring.model.Person;
import com.example.TopExamSpring.model.Product;
import com.example.TopExamSpring.service.PersonService;
import com.example.TopExamSpring.service.ProductService;
import com.example.TopExamSpring.util.PersonValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.security.Principal;

@Controller
@RequestMapping("/person")
public class PersonController {
    private final PersonService personService;
    private final PersonValidator personValidator;
    private final ProductService productService;

    @Autowired
    public PersonController(PersonService personService, PersonValidator personValidator, ProductService productService) {
        this.personService = personService;
        this.personValidator = personValidator;
        this.productService = productService;
    }

    @GetMapping()
    public String pagePerson(Model model, Principal principal){
        model.addAttribute("person", productService.getUserByPrincipal(principal));
        return "person/person_page";
    }

    @GetMapping("/{id}")
    public String getOnePerson(Model model, @PathVariable("id") int id) {
        model.addAttribute("person", personService.getPersonId(id));
        model.addAttribute("products", personService.getProductByPerson(id));
        model.addAttribute("product", productService.getOneProduct(id));
        return "person/person_page";
    }

    @GetMapping("/{id}/product")
    private String getInfoProduct(Model model, @PathVariable("id") int id) {
        model.addAttribute("product", productService.getOneProduct(id));
        return "person/show_product";
    }

    @GetMapping("/{id}/edit")
    public String editPerson(Model model, @PathVariable("id") int id) {
        model.addAttribute("person", personService.getPersonId(id));
        return "person/edit_profile";
    }

    @PatchMapping("/{id}")
    public String updatePerson(@ModelAttribute("person") @Valid Person person, BindingResult bindingResult,
                               @PathVariable("id") int id) {
        personValidator.validate(person, bindingResult);
        if (bindingResult.hasErrors()) {
            return "person/edit_profile";
        }
        personService.updatePeron(id, person);
        return "redirect:/person/{id}";
    }

    @GetMapping("/new")
    public String newProduct(@ModelAttribute("product") Product product) {
        return "person/new_product";
    }

    @PostMapping("/new")
    public String createProduct(@ModelAttribute("product") @Valid Product product, BindingResult bindingResult,
                                Principal principal) {
        if(bindingResult.hasErrors()) {
            return "person/new_product";
        }
        int idPerson = productService.getUserByPrincipal(principal).getId();
        productService.createProduct(product,principal);
        return "redirect:/person/" + idPerson;//исправить ошибку
    }

    @GetMapping("/{id}/edit_product")
    public String editProduct(@ModelAttribute("product") Product product, @PathVariable("id") int id) {
        productService.getOneProduct(id);
        return "person/edit_product";
    }

    @PatchMapping("/{id}/edit_product")
    public String updateProduct(@ModelAttribute("product") @Valid Product product, BindingResult bindingResult,
                                @PathVariable("id") int id, Principal principal) {
        if (bindingResult.hasErrors()) {
            return "person/edit_product";
        }
        int idPerson = productService.getUserByPrincipal(principal).getId();
        productService.updateProduct(id, product, principal);

        return "redirect:/person/" + idPerson;//исправить ошибку
    }

    @DeleteMapping("/{id}")
    public String deleteProduct(@PathVariable("id") int id, Principal principal) {
        int idPerson = productService.getUserByPrincipal(principal).getId();
        productService.deleteProduct(id);
        return "redirect:/person/" + idPerson;//исправить ошибку
    }

}
