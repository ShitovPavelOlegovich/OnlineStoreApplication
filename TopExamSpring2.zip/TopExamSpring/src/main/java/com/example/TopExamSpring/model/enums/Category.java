package com.example.TopExamSpring.model.enums;

public enum Category {
    PRODUCT_AUTO,
    PRODUCT_ELECTRONIC,
    PRODUCT_HOME,
    PRODUCT_CLOTH,
    PRODUCT_REAL_ESTATE,
    PRODUCT_JOB;
}
